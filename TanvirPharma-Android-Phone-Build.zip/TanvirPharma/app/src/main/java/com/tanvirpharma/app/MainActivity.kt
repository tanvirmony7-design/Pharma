package com.tanvirpharma.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF087C55)
private val Pale = Color(0xFFEAF5EF)

data class Medicine(val name: String, val strength: String, val batch: String, val stock: Int, val price: Double, val expiry: String)
data class Customer(val name: String, val phone: String)
data class Sale(val medicine: String, val qty: Int, val total: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TanvirPharmaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TanvirPharmaApp() {
    var bangla by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf(0) }
    var medicines by remember {
        mutableStateOf(listOf(
            Medicine("Napa", "500 mg", "NP-2401", 420, 1.20, "2027-08"),
            Medicine("Seclo", "20 mg", "SC-1108", 85, 6.00, "2027-01"),
            Medicine("Ceevit", "250 mg", "CV-0902", 12, 3.00, "2026-12")
        ))
    }
    var customers by remember { mutableStateOf(listOf(Customer("Rahim Uddin", "01700000000"))) }
    var sales by remember { mutableStateOf(listOf(Sale("Napa", 10, 12.0), Sale("Seclo", 2, 12.0))) }
    var showAddMedicine by remember { mutableStateOf(false) }
    var showAddCustomer by remember { mutableStateOf(false) }
    var showSale by remember { mutableStateOf(false) }
    val labels = if (bangla) listOf("ড্যাশবোর্ড", "ওষুধ", "স্টক", "বিক্রি", "কাস্টমার", "রিপোর্ট") else listOf("Dashboard", "Medicines", "Stock", "Sales", "Customers", "Reports")

    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Color(0xFF48A879), background = Color(0xFFF7FAF8))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Tanvir Pharma", fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Pharmaceutical Management", fontSize = 11.sp, color = Color.White.copy(alpha = .85f))
                        }
                    },
                    actions = {
                        TextButton(onClick = { bangla = !bangla }) {
                            Text(if (bangla) "EN" else "বাংলা", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Green)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val icons = listOf(Icons.Default.Home, Icons.Default.Medication, Icons.Default.Inventory, Icons.Default.PointOfSale, Icons.Default.People, Icons.Default.BarChart)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label, fontSize = 9.sp, maxLines = 1) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).background(Color(0xFFF7FAF8))) {
                when (tab) {
                    0 -> Dashboard(bangla, medicines, sales, customers.size, onAdd = { showAddMedicine = true }, onSale = { showSale = true })
                    1, 2 -> MedicineScreen(bangla, medicines, onAdd = { showAddMedicine = true })
                    3 -> SalesScreen(bangla, sales, onSale = { showSale = true })
                    4 -> CustomerScreen(bangla, customers, onAdd = { showAddCustomer = true })
                    else -> ReportsScreen(bangla, sales)
                }
            }
        }
    }

    if (showAddMedicine) AddMedicineDialog(bangla, onDismiss = { showAddMedicine = false }) { m ->
        medicines = medicines + m
        showAddMedicine = false
    }
    if (showAddCustomer) AddCustomerDialog(bangla, onDismiss = { showAddCustomer = false }) { c ->
        customers = customers + c
        showAddCustomer = false
    }
    if (showSale) SaleDialog(bangla, medicines, onDismiss = { showSale = false }) { medicine, qty ->
        val found = medicines.firstOrNull { it.name.equals(medicine, true) }
        if (found != null && qty > 0 && found.stock >= qty) {
            sales = sales + Sale(found.name, qty, found.price * qty)
            medicines = medicines.map { if (it.name == found.name) it.copy(stock = it.stock - qty) else it }
        }
        showSale = false
    }
}

@Composable
fun PageTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(bottom = 14.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173B2C))
        if (subtitle != null) Text(subtitle, color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun Dashboard(bn: Boolean, meds: List<Medicine>, sales: List<Sale>, customers: Int, onAdd: () -> Unit, onSale: () -> Unit) {
    val totalStock = meds.sumOf { it.stock }
    val revenue = sales.sumOf { it.total }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            PageTitle(if (bn) "স্বাগতম 👋" else "Welcome 👋", if (bn) "আপনার কোম্পানির সারসংক্ষেপ" else "Your company overview")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(if (bn) "মোট পণ্য" else "Products", meds.size.toString(), Icons.Default.Medication, Modifier.weight(1f))
                MetricCard(if (bn) "মোট স্টক" else "Stock units", totalStock.toString(), Icons.Default.Inventory, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard(if (bn) "বিক্রি" else "Sales total", "৳${"%.2f".format(revenue)}", Icons.Default.TrendingUp, Modifier.weight(1f))
                MetricCard(if (bn) "কাস্টমার" else "Customers", customers.toString(), Icons.Default.People, Modifier.weight(1f))
            }
        }
        item {
            Text(if (bn) "দ্রুত কাজ" else "Quick actions", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(onClick = onAdd, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text(if (bn) "ওষুধ যোগ" else "Add medicine") }
                OutlinedButton(onClick = onSale, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Receipt, null); Spacer(Modifier.width(4.dp)); Text(if (bn) "বিল তৈরি" else "New bill") }
            }
        }
        item { Text(if (bn) "মেয়াদ ও স্টক সতর্কতা" else "Expiry & stock alerts", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        items(meds.filter { it.stock < 20 || it.expiry <= "2027-01" }) { m ->
            AlertRow("${m.name} • ${m.batch}", if (m.stock < 20) (if (bn) "স্টক কম: ${m.stock}" else "Low stock: ${m.stock}") else (if (bn) "মেয়াদ: ${m.expiry}" else "Expiry: ${m.expiry}"))
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Green)
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun AlertRow(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5E8))) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.WarningAmber, null, tint = Color(0xFFB66B00))
            Spacer(Modifier.width(10.dp))
            Column { Text(title, fontWeight = FontWeight.SemiBold); Text(detail, fontSize = 12.sp, color = Color.DarkGray) }
        }
    }
}

@Composable
fun MedicineScreen(bn: Boolean, meds: List<Medicine>, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { PageTitle(if (bn) "ওষুধ ও স্টক" else "Medicines & stock", if (bn) "ব্যাচ, দাম এবং মেয়াদ" else "Batch, price and expiry") }
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text(if (bn) "যোগ" else "Add") }
        }
        OutlinedButton(onClick = {}, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCodeScanner, null); Text(if (bn) "বারকোড স্ক্যান (পরবর্তী ধাপে ক্যামেরা যুক্ত হবে)" else "Barcode scanner (camera integration next)") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(meds) { m ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(m.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                            Text("৳${"%.2f".format(m.price)}", color = Green, fontWeight = FontWeight.Bold)
                        }
                        Text("${m.strength} • Batch ${m.batch}", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(5.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text((if (bn) "স্টক: " else "Stock: ") + m.stock)
                            Text((if (bn) "মেয়াদ: " else "Expiry: ") + m.expiry, color = if (m.expiry <= "2027-01") Color(0xFFB66B00) else Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SalesScreen(bn: Boolean, sales: List<Sale>, onSale: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { PageTitle(if (bn) "বিক্রি ও বিল" else "Sales & billing") }
            Button(onClick = onSale) { Icon(Icons.Default.Add, null); Text(if (bn) "নতুন বিল" else "New bill") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sales.reversed()) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(s.medicine, fontWeight = FontWeight.Bold); Text("Qty: ${s.qty}", color = Color.Gray, fontSize = 12.sp) }
                        Text("৳${"%.2f".format(s.total)}", color = Green, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerScreen(bn: Boolean, customers: List<Customer>, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { PageTitle(if (bn) "কাস্টমার" else "Customers") }
            Button(onClick = onAdd) { Icon(Icons.Default.Add, null); Text(if (bn) "যোগ" else "Add") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(customers) { c ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountCircle, null, tint = Green)
                        Spacer(Modifier.width(12.dp))
                        Column { Text(c.name, fontWeight = FontWeight.Bold); Text(c.phone, color = Color.Gray, fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(bn: Boolean, sales: List<Sale>) {
    val total = sales.sumOf { it.total }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PageTitle(if (bn) "রিপোর্ট" else "Reports", if (bn) "ডেমো বিক্রির সারসংক্ষেপ" else "Demo sales summary")
        MetricCard(if (bn) "মোট বিক্রি" else "Total sales", "৳${"%.2f".format(total)}", Icons.Default.Payments, Modifier.fillMaxWidth())
        MetricCard(if (bn) "মোট ইনভয়েস" else "Invoices", sales.size.toString(), Icons.Default.ReceiptLong, Modifier.fillMaxWidth())
        Text(if (bn) "দৈনিক ও মাসিক রিপোর্টের ডেটা বাস্তব ব্যবহারের জন্য ডাটাবেস ও তারিখভিত্তিক ফিল্টার যুক্ত করতে হবে।" else "Database and date filters are required for production daily/monthly reports.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
fun AddMedicineDialog(bn: Boolean, onDismiss: () -> Unit, onSave: (Medicine) -> Unit) {
    var name by remember { mutableStateOf("") }; var strength by remember { mutableStateOf("") }
    var batch by remember { mutableStateOf("") }; var stock by remember { mutableStateOf("0") }
    var price by remember { mutableStateOf("0") }; var expiry by remember { mutableStateOf("2027-12") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (bn) "নতুন ওষুধ" else "Add medicine") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text(if (bn) "ওষুধের নাম" else "Medicine name") }, singleLine = true)
            OutlinedTextField(strength, { strength = it }, label = { Text("Strength") }, singleLine = true)
            OutlinedTextField(batch, { batch = it }, label = { Text("Batch no.") }, singleLine = true)
            OutlinedTextField(stock, { stock = it }, label = { Text("Stock quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            OutlinedTextField(price, { price = it }, label = { Text("Price (BDT)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(expiry, { expiry = it }, label = { Text("Expiry (YYYY-MM)") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(Medicine(name, strength, batch, stock.toIntOrNull() ?: 0, price.toDoubleOrNull() ?: 0.0, expiry)) }) { Text(if (bn) "সংরক্ষণ" else "Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (bn) "বাতিল" else "Cancel") } })
}

@Composable
fun AddCustomerDialog(bn: Boolean, onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (bn) "কাস্টমার যোগ" else "Add customer") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text(if (bn) "নাম" else "Name") })
            OutlinedTextField(phone, { phone = it }, label = { Text(if (bn) "মোবাইল" else "Phone") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        } },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(Customer(name, phone)) }) { Text(if (bn) "সংরক্ষণ" else "Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (bn) "বাতিল" else "Cancel") } })
}

@Composable
fun SaleDialog(bn: Boolean, medicines: List<Medicine>, onDismiss: () -> Unit, onSave: (String, Int) -> Unit) {
    var selected by remember { mutableStateOf(medicines.firstOrNull()?.name ?: "") }
    var qty by remember { mutableStateOf("1") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (bn) "নতুন বিক্রি" else "New sale") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (bn) "ওষুধ নির্বাচন" else "Select medicine")
            medicines.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected == m.name, onClick = { selected = m.name })
                    Text("${m.name} (stock ${m.stock})")
                }
            }
            OutlinedTextField(qty, { qty = it }, label = { Text(if (bn) "পরিমাণ" else "Quantity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        } },
        confirmButton = { TextButton(onClick = { onSave(selected, qty.toIntOrNull() ?: 0) }) { Text(if (bn) "বিক্রি নিশ্চিত" else "Confirm sale") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(if (bn) "বাতিল" else "Cancel") } })
}
