package com.tanvirpharma.app.cloud

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.tasks.await

/** Firebase-backed foundation. A Firebase project + google-services.json are required. */
class CloudRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    data class StaffProfile(val uid: String, val name: String, val role: String, val branchId: String)
    data class MedicineRecord(
        val id: String = "", val name: String = "", val genericName: String = "",
        val strength: String = "", val batchNo: String = "", val barcode: String = "",
        val quantity: Long = 0, val unitPrice: Double = 0.0, val expiryDate: String = "",
        val branchId: String = "", val updatedAt: Long = 0
    )

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun loadMyProfile(): StaffProfile {
        val uid = auth.currentUser?.uid ?: error("Not signed in")
        val snap = db.collection("users").document(uid).get().await()
        check(snap.exists()) { "Your account has not been activated by an administrator." }
        return StaffProfile(uid, snap.getString("name") ?: "", snap.getString("role") ?: "viewer", snap.getString("branchId") ?: "")
    }

    fun observeMedicines(branchId: String, onUpdate: (List<MedicineRecord>) -> Unit, onError: (Exception) -> Unit): ListenerRegistration {
        return db.collection("medicines").whereEqualTo("branchId", branchId)
            .orderBy("name", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) { onError(error); return@addSnapshotListener }
                onUpdate(snapshot?.documents?.mapNotNull { d -> d.toObject(MedicineRecord::class.java)?.copy(id = d.id) } ?: emptyList())
            }
    }

    fun signOut() = auth.signOut()
}
